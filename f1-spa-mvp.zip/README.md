# F1 Spa MVP (CSV-driven UI)

This starter loads CSV UI + design tokens and renders a minimal racing HUD. Includes a tiny Express backend for PBs.
