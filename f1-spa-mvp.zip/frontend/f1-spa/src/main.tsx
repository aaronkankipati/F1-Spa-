import React from 'react';
import ReactDOM from 'react-dom/client';
import TokenProvider from './ui/TokenProvider';
import UiFromCsv from './ui/UiFromCsv';
import { useGameStore } from './state/store';
import { startGame } from './engine/GameLoop';
import './app.css';

function ScreenRouter(){
  const screen = useGameStore(s=>s.screen);
  React.useEffect(()=>{ if(screen==='RACE') startGame(); },[screen]);
  return <>
    <canvas id="scene" width={1280} height={960} style={{position:'absolute', inset:0, margin:'auto'}} />
    <UiFromCsv screen={screen as any}/>
  </>;
}

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <TokenProvider>
      <ScreenRouter/>
    </TokenProvider>
  </React.StrictMode>
);
