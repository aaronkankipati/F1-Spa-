import { create } from 'zustand';

export type GameStore = {
  screen:'MAIN'|'SETTINGS'|'RACE'|'PAUSE'|'RESULTS';
  telemetry:{ speedKph:number; gear:number };
  timing:{ deltaMs:number; pbMs:number|null };
  race:{ currentLap:number; started:boolean; finished:boolean; drsActive:boolean; penaltyActive:boolean };
  update:(dt:number)=>void;
  render:()=>void;
  pause:()=>void; restart:()=>void; openScreen:(s:GameStore['screen'])=>void;
};

export const useGameStore = create<GameStore>((set,get)=>({
  screen:'MAIN',
  telemetry:{ speedKph:0, gear:1 },
  timing:{ deltaMs:0, pbMs:null },
  race:{ currentLap:1, started:false, finished:false, drsActive:false, penaltyActive:false },
  update:(dt)=>{
    const t = get().timing;
    set({ timing:{ ...t, deltaMs: Math.sin(performance.now()/500)*120 }});
  },
  render:()=>{},
  pause:()=> set({ screen:'PAUSE' }),
  restart:()=> set({ screen:'RACE', race:{ currentLap:1, started:false, finished:false, drsActive:false, penaltyActive:false } }),
  openScreen:(s)=> set({ screen:s }),
}));
