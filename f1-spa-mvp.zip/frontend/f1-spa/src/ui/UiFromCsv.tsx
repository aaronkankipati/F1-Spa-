import React, { useEffect, useState } from 'react';
import Papa from 'papaparse';
import { useGameStore } from '../state/store';
import { getHudBinding } from './HudBindings';

type Row = {
  screen_id:string; component_id:string; component_name:string;
  component_type:string; aria_role?:string; a11y_label?:string;
  state?:string; x?:string; y?:string; width?:string; height?:string;
  visible?:string; data_binding?:string; copy_text?:string; interaction?:string; asset_ref?:string;
};

export default function UiFromCsv({screen}:{screen:'MAIN'|'SETTINGS'|'RACE'|'PAUSE'|'RESULTS'}) {
  const [rows, setRows] = useState<Row[]>([]);
  const store = useGameStore();
  useEffect(()=>{
    Papa.parse('/ui_spec.csv', { header:true, download:true, complete:(r:any)=>{
      setRows((r.data as Row[]).filter((x:Row)=>x.screen_id===screen));
    }});
  },[screen]);

  return (
    <>
      {rows.map((r:Row)=>{
        const style:React.CSSProperties = {
          position:'absolute',
          left: px(r.x), top: px(r.y),
          width: px(r.width), height: px(r.height),
          zIndex: 10,
          display: r.visible==='false' ? 'none' : 'block'
        };
        const content = r.copy_text || getHudBinding(r.data_binding||'', store);
        const role = r.aria_role || undefined;
        if(r.component_type==='button'){
          return <button key={r.component_id} role={role} aria-label={r.a11y_label||undefined}
            className="hud-chip" style={style} onClick={()=>runInteraction(r.interaction||'', store)}>
              {content || r.component_name}
          </button>;
        }
        if(r.component_type==='banner'){
          return <div key={r.component_id} role="alert" className="hud-chip" style={{...style, border:'1px solid var(--color-error,#FF5D5D)'}}>
            {content}
          </div>;
        }
        if(r.component_type==='icon' && r.asset_ref){
          return <img key={r.component_id} alt={r.a11y_label||r.component_name} src={`/${r.asset_ref}`} style={style}/>;
        }
        return <div key={r.component_id} role={role} aria-label={r.a11y_label||undefined}
          className="hud-chip" style={style}>{content}</div>;
      })}
    </>
  );
}

const px = (v?:string)=> v && v!=='center' ? `${v}px` : undefined;

function runInteraction(interaction:string, store:any){
  if(interaction.includes('navigate(')){
    const target = interaction.match(/navigate\(([^)]+)\)/)?.[1] as any;
    if(target) store.openScreen(target);
  }
  if(interaction.includes('pause')) store.pause();
  if(interaction.includes('restartRace')) store.restart();
  if(interaction.includes('open(PAUSE)')) store.openScreen('PAUSE');
}
