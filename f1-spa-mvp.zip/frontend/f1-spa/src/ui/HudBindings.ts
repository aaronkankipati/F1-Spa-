import { GameStore } from '../state/store';
export function getHudBinding(binding: string, store: GameStore){
  switch(binding){
    case 'telemetry.speedKph': return Math.round(store.telemetry.speedKph);
    case 'telemetry.gear': return store.telemetry.gear;
    case 'race.lapText': return `Lap ${store.race.currentLap}/5`;
    case 'timing.deltaMs': return store.timing.deltaMs;
    case 'timing.deltaFmt': return fmtMs(store.timing.deltaMs);
    case 'timing.pbLap': return store.timing.pbMs ? `PB: ${fmtMs(store.timing.pbMs)}` : 'PB: --';
    default: return '';
  }
}
const fmtMs = (ms:number)=> (ms>=0?'+':'') + (ms/1000).toFixed(3)+'s';
