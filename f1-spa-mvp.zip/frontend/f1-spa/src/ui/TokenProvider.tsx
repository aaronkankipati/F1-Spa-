import React, { createContext, useEffect, useMemo, useState } from 'react';
import Papa from 'papaparse';

export type Token = { token_id:string; token_type:string; value:string; description?:string };
export const TokenCtx = createContext<Record<string,string>>({});

export default function TokenProvider({children}:{children:React.ReactNode}) {
  const [tokens, setTokens] = useState<Token[]>([]);
  useEffect(()=>{
    Papa.parse('/design_tokens.csv', {
      header:true, download:true, complete:(r)=>setTokens(r.data as Token[])
    });
  },[]);
  const map = useMemo(()=>{
    const o:Record<string,string> = {};
    tokens.forEach(t=>{ if(t.token_id && t.value) o[t.token_id] = String(t.value); });
    const root = document.documentElement;
    Object.entries(o).forEach(([k,v])=>{
      root.style.setProperty(`--${k.replaceAll('.','-')}`, String(v));
    });
    return o;
  },[tokens]);
  return <TokenCtx.Provider value={map}>{children}</TokenCtx.Provider>;
}
