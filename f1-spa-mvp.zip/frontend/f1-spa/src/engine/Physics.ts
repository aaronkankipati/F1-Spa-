export type CarState = { x:number; y:number; heading:number; speed:number; gear:number };
export function stepCar(car:CarState, input:{throttle:number;brake:number;steer:number}, dtMs:number){
  const dt = dtMs/1000;
  const accel = 30*input.throttle - 40*input.brake - 0.02*car.speed*car.speed;
  car.speed = Math.max(0, car.speed + accel*dt);
  car.heading += input.steer * 1.8 * dt;
  car.x += Math.cos(car.heading)*car.speed*dt;
  car.y += Math.sin(car.heading)*car.speed*dt;
  car.gear = Math.min(8, Math.max(1, Math.floor(car.speed/40)+1));
}
