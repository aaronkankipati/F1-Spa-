import { useGameStore } from '../state/store';
let last = 0;
const FIXED_DT = 1000/60;

export function startGame(){
  last = performance.now();
  requestAnimationFrame(tick);
}
function tick(now:number){
  const store = useGameStore.getState();
  let acc = now - last;
  while(acc >= FIXED_DT){
    store.update(FIXED_DT);
    acc -= FIXED_DT;
    last += FIXED_DT;
  }
  store.render();
  requestAnimationFrame(tick);
}
