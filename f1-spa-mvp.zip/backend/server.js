const express = require('express');
const fs = require('fs');
const path = require('path');
const app = express();
app.use(express.json());

const DB_PATH = path.join(__dirname, 'db.json');
function readDB(){ try { return JSON.parse(fs.readFileSync(DB_PATH,'utf8')); } catch { return {pbs:{}}; } }
function writeDB(data){ fs.writeFileSync(DB_PATH, JSON.stringify(data,null,2)); }

app.get('/api/health', (_,res)=>res.json({ok:true}));

app.get('/api/pb', (req,res)=>{
  const db = readDB();
  res.json({ pbMs: db.pbs?.spa5lap ?? null });
});

app.post('/api/pb', (req,res)=>{
  const { pbMs } = req.body;
  if(typeof pbMs!=='number' || pbMs<=0) return res.status(400).json({error:'invalid pb'});
  const db = readDB();
  if(!db.pbs) db.pbs = {};
  db.pbs.spa5lap = db.pbs.spa5lap ? Math.min(db.pbs.spa5lap, pbMs) : pbMs;
  writeDB(db);
  res.json({ ok:true, pbMs: db.pbs.spa5lap });
});

const PORT = process.env.PORT || 3001;
app.listen(PORT, ()=> console.log(`BED on :${PORT}`));
